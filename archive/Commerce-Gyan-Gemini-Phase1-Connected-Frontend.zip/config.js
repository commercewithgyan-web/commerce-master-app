// Public project settings for the isolated Commerce Gyan Phase 1 test database.
// This publishable key is safe for browsers. Never put a secret/service key here.
window.ERP_CONFIG = { url: "https://jhxyddvkzncpimumhdbr.supabase.co", publishableKey: "sb_publishable_pQXMniri9LAndjvssAA3tw_HoTCFpcz" };
