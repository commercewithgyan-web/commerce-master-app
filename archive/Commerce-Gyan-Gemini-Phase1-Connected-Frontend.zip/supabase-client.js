/* Isolated Phase 1 candidate. Requires the matching 001–004 schema and an admin account. */
(() => {
  const $ = id => document.getElementById(id);
  const cfg = window.ERP_CONFIG || {};
  const ready = /^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(cfg.url || '') &&
    !!cfg.publishableKey && !!window.supabase;
  const db = ready ? window.supabase.createClient(cfg.url, cfg.publishableKey) : null;
  const state = { students: [], batches: [], subjects: [], enquiries: [], payments: [], obligations: [], balances: [], prepared: null };
  const money = n => '₹' + Number(n || 0).toFixed(2);
  const note = (id, value) => { $(id).textContent = value; };
  const fail = (id, error) => note(id, error.message || String(error));
  const option = (value, label) => { const el = document.createElement('option'); el.value = value; el.textContent = label; return el; };
  const setOptions = (id, rows) => $(id).replaceChildren(option('', 'Select…'), ...rows.map(r => option(r.id, r.label)));
  const card = (parent, label, actions = []) => {
    const row = document.createElement('p'); row.textContent = label + ' ';
    for (const [title, action] of actions) {
      const btn = document.createElement('button'); btn.type = 'button'; btn.className = 'btn btn-outline';
      btn.textContent = title; btn.onclick = action; row.append(btn, ' ');
    }
    parent.append(row);
  };
  async function query(table) {
    const { data, error } = await db.from(table).select('*');
    if (error) throw error;
    return data;
  }
  async function rpc(name, payload) {
    const { data, error } = await db.rpc(name, payload);
    if (error) throw error;
    return data;
  }
  async function refresh() {
    if (!db) return;
    try {
      const { data: { user }, error } = await db.auth.getUser();
      if (error) throw error;
      $('authStatus').textContent = user ? `Signed in: ${user.email}` : 'Not signed in';
      if (!user) return;
      [state.enquiries, state.students, state.batches, state.subjects, state.payments, state.obligations, state.balances] = await Promise.all([
        query('enquiries'), query('students'), query('batches'), query('subjects'), query('payments'),
        query('fee_obligations'), query('v_fee_obligation_balances')
      ]);
      const today = new Date().toISOString().slice(0, 10);
      $('kpiActiveStudents').textContent = `${state.students.filter(s => s.status === 'Active').length} / 100`;
      $('kpiFollowUps').textContent = state.enquiries.filter(e => e.follow_up_date && e.follow_up_date <= today && !['Converted', 'Closed_Lost'].includes(e.status)).length;
      $('kpiCollections').textContent = money(state.payments.filter(p => p.verification_status === 'Verified' && !p.is_reversed && p.payment_date?.startsWith(today.slice(0, 7))).reduce((n, p) => n + Number(p.amount_received_inr), 0));
      $('kpiOverdue').textContent = money(state.balances.filter(b => b.due_date < today).reduce((n, b) => n + Number(b.outstanding_balance_inr), 0));
      render();
    } catch (error) { fail('loginStatus', error); }
  }
  function render() {
    $('enquiryList').replaceChildren();
    state.enquiries.filter(e => !e.is_archived).forEach(e => card($('enquiryList'),
      `${e.enquiry_code} · ${e.student_name} · ${e.status}`,
      e.converted_student_id ? [] : [['Convert to admission', () => convert(e)]]));
    $('studentList').replaceChildren();
    state.students.forEach(s => card($('studentList'), `${s.student_code} · ${s.full_name} · ${s.status}`));
    $('batchList').replaceChildren();
    state.batches.forEach(b => card($('batchList'), `${b.batch_code} · ${b.batch_name} · ${b.days_of_week.join(', ')} ${b.start_time}–${b.end_time}`));
    setOptions('batchStudent', state.students.filter(s => s.status === 'Active').map(s => ({ id: s.id, label: s.full_name })));
    setOptions('obligationStudent', state.students.filter(s => s.status === 'Active').map(s => ({ id: s.id, label: s.full_name })));
    setOptions('payStudent', state.students.map(s => ({ id: s.id, label: s.full_name })));
    setOptions('batchChoice', state.batches.filter(b => b.is_active).map(b => ({ id: b.id, label: b.batch_name })));
    setOptions('newBatchSubject', state.subjects.filter(s => s.is_active).map(s => ({ id: s.id, label: s.name })));
    $('obligationList').replaceChildren();
    state.balances.forEach(b => card($('obligationList'),
      `${b.student_name} · ${b.billing_month} · due ${money(b.total_payable_inr)} · paid ${money(b.net_verified_paid_inr)} · pending ${money(b.pending_verification_inr)} · outstanding ${money(b.outstanding_balance_inr)}`,
      [['Adjust', () => adjust(b)], ...(b.applied_penalty_inr > 0 ? [['Reverse penalty', () => reversePenalty(b)]] : [['Assess penalty', () => assessPenalty(b)]])]
    ));
    $('paymentList').replaceChildren();
    state.payments.sort((a, b) => b.created_at.localeCompare(a.created_at)).forEach(p => {
      const student = state.students.find(s => s.id === p.student_id);
      const actions = p.verification_status === 'Pending_Verification'
        ? [['Verify', () => resolvePayment(p, true)], ['Reject', () => resolvePayment(p, false)]]
        : p.verification_status === 'Verified' && !p.is_reversed
          ? [['View receipt', () => showReceipt(p, student)], ['Refund', () => refund(p)]] : [];
      card($('paymentList'), `${p.receipt_number || 'No receipt'} · ${student?.full_name || 'Student'} · ${money(p.amount_received_inr)} · ${p.verification_status}`, actions);
    });
    updatePaymentOptions();
  }
  function updatePaymentOptions() {
    const studentId = $('payStudent').value;
    setOptions('payObligation', state.balances.filter(b => b.student_id === studentId &&
      Number(b.total_payable_inr) > Number(b.net_verified_paid_inr) + Number(b.pending_verification_inr))
      .map(b => ({ id: b.obligation_id, label: `${b.billing_month} · available ${money(Number(b.total_payable_inr) - Number(b.net_verified_paid_inr) - Number(b.pending_verification_inr))}` })));
  }
  async function convert(e) {
    const guardian = prompt(`Guardian name for ${e.student_name}:`); if (!guardian) return;
    const phone = prompt('Guardian 10-digit phone:'); if (!phone) return;
    const fee = prompt('Agreed monthly fee in ₹:'); if (fee === null) return;
    try {
      await rpc('convert_enquiry', { p_enquiry_id: e.id, p_guardian_name: guardian,
        p_guardian_phone: phone, p_monthly_fee: Number(fee) });
      note('studentStatus', 'Admission saved.'); await refresh();
    } catch (error) { fail('studentStatus', error); }
  }
  window.handleEnquirySubmit = async event => {
    event.preventDefault();
    if (!db) return note('enquiryStatus', 'No database configured.');
    const subjects = [...$('enqSubjects').selectedOptions].map(x => x.value);
    if (!subjects.length) return note('enquiryStatus', 'Choose at least one subject.');
    const payload = { student_name: $('enqName').value.trim(), class_level: Number($('enqClass').value),
      board: $('enqBoard').value, contact_phone: $('enqPhone').value,
      whatsapp_same_as_contact: $('enqSameWa').checked, whatsapp_phone: $('enqWaPhone').value,
      interested_subjects: subjects, lead_source: $('enqSource').value.trim() || 'Walk-In',
      follow_up_date: $('enqFollowUp').value || null, notes: $('enqNotes').value };
    try {
      const { error } = await db.from('enquiries').insert(payload); if (error) throw error;
      note('enquiryStatus', 'Enquiry saved.'); event.target.reset(); window.syncEnqWhatsApp(); await refresh();
    } catch (error) { fail('enquiryStatus', error); }
  };
  $('batchForm').onsubmit = async event => {
    event.preventDefault(); if (!db) return note('batchStatus', 'No database configured.');
    try {
      await rpc('assign_batch', { p_student_id: $('batchStudent').value, p_batch_id: $('batchChoice').value });
      note('batchStatus', 'Batch assigned.'); await refresh();
    } catch (error) { fail('batchStatus', error); }
  };
  $('createBatchForm').onsubmit = async event => {
    event.preventDefault(); if (!db) return note('createBatchStatus', 'No database configured.');
    const days = $('newBatchDays').value.split(',').map(x => x.trim()).filter(Boolean);
    const payload = { batch_code: $('newBatchCode').value.trim(), batch_name: $('newBatchName').value.trim(),
      class_level: Number($('newBatchClass').value), board: $('newBatchBoard').value,
      subject_id: $('newBatchSubject').value, days_of_week: days,
      start_time: $('newBatchStart').value, end_time: $('newBatchEnd').value,
      capacity: Number($('newBatchCapacity').value) };
    try {
      const { error } = await db.from('batches').insert(payload); if (error) throw error;
      note('createBatchStatus', 'Batch created.'); await refresh();
    } catch (error) { fail('createBatchStatus', error); }
  };
  $('obligationForm').onsubmit = async event => {
    event.preventDefault(); if (!db) return note('obligationStatus', 'No database configured.');
    try {
      await rpc('create_monthly_obligation', { p_student_id: $('obligationStudent').value,
        p_month: $('obligationMonth').value + '-01' });
      note('obligationStatus', 'Monthly obligation ready.'); await refresh();
    } catch (error) { fail('obligationStatus', error); }
  };
  async function assessPenalty(b) {
    const reason = prompt(`Reason to assess a 5% penalty for ${b.student_name}:`); if (!reason) return;
    try { await rpc('assess_fee_penalty', { p_obligation_id: b.obligation_id, p_note: reason }); await refresh(); }
    catch (error) { fail('obligationStatus', error); }
  }
  async function reversePenalty(b) {
    const reason = prompt(`Reason to reverse penalty for ${b.student_name}:`); if (!reason) return;
    try { await rpc('reverse_fee_penalty', { p_obligation_id: b.obligation_id, p_reason: reason }); await refresh(); }
    catch (error) { fail('obligationStatus', error); }
  }
  async function adjust(b) {
    const kind = prompt('Adjustment kind: Discount_Fixed, Discount_Percent, Waiver, or Debit_Adjustment');
    if (!kind) return;
    const value = prompt(kind === 'Discount_Percent' ? 'Percent (0–100):' : 'Amount in ₹:');
    if (value === null) return;
    const reason = prompt('Reason:'); if (!reason) return;
    try { await rpc('add_fee_adjustment', { p_obligation_id: b.obligation_id, p_kind: kind,
      p_value: Number(value), p_reason: reason }); await refresh(); }
    catch (error) { fail('obligationStatus', error); }
  }
  $('payStudent').onchange = updatePaymentOptions;
  $('paymentForm').onsubmit = async event => {
    event.preventDefault(); if (!db) return note('paymentStatus', 'No database configured.');
    try {
      await rpc('record_pending_payment', { p_student_id: $('payStudent').value,
        p_obligation_id: $('payObligation').value, p_amount: Number($('payAmount').value),
        p_method: $('payMethod').value, p_reference: $('payReference').value });
      note('paymentStatus', 'Pending payment recorded. No receipt issued yet.');
      $('payAmount').value = ''; $('payReference').value = ''; await refresh();
    } catch (error) { fail('paymentStatus', error); }
  };
  async function resolvePayment(p, verify) {
    const explanation = prompt(verify ? 'Bank or cash reconciliation note:' : 'Rejection reason:');
    if (!explanation) return;
    try {
      await rpc('resolve_pending_payment', { p_payment_id: p.id, p_verify: verify, p_note: explanation });
      note('paymentStatus', verify ? 'Payment verified. Receipt issued.' : 'Payment rejected.'); await refresh();
    } catch (error) { fail('paymentStatus', error); }
  }
  async function refund(p) {
    const amount = prompt('Refund amount in ₹:'); if (amount === null) return;
    const method = prompt('Refund method: Cash, UPI, or Bank_Transfer'); if (!method) return;
    const reference = prompt('Refund reference (optional):'); if (reference === null) return;
    const reason = prompt('Refund reason:'); if (!reason) return;
    try {
      await rpc('record_payment_refund', { p_payment_id: p.id, p_amount: Number(amount),
        p_method: method, p_reference: reference, p_reason: reason });
      note('paymentStatus', 'Refund recorded.'); await refresh();
    } catch (error) { fail('paymentStatus', error); }
  }
  function showReceipt(p, student) {
    if (p.verification_status !== 'Verified' || !p.receipt_number || !p.verified_at) return;
    const lines = ['Commerce Gyan · Verified Payment Acknowledgement',
      `Receipt: ${p.receipt_number}`, `Student: ${student?.full_name || ''}`,
      `Student ID: ${student?.student_code || ''}`, `Amount received: ${money(p.amount_received_inr)}`,
      `Payment method: ${p.payment_method}`, `Payment date: ${p.payment_date}`,
      `Reference: ${p.reference_note || '—'}`,
      `Verified at: ${new Date(p.verified_at).toLocaleString('en-IN')}`];
    $('receiptDetails').replaceChildren(...lines.map(line => {
      const paragraph = document.createElement('p'); paragraph.textContent = line; return paragraph;
    }));
    $('printableReceipt').classList.remove('hidden');
    $('printableReceipt').scrollIntoView({ behavior: 'smooth' });
  }
  $('printReceipt').onclick = () => { document.body.classList.add('receipt-print'); window.print(); };
  window.addEventListener('afterprint', () => document.body.classList.remove('receipt-print'));
  $('loginForm').onsubmit = async event => {
    event.preventDefault(); if (!db) return note('loginStatus', 'No database configured.');
    const { error } = await db.auth.signInWithPassword({ email: $('loginEmail').value,
      password: $('loginPassword').value });
    $('loginPassword').value = '';
    if (error) fail('loginStatus', error); else { note('loginStatus', 'Signed in.'); await refresh(); }
  };
  $('logoutButton').onclick = async () => { if (db) await db.auth.signOut(); location.reload(); };
  window.openWhatsAppManual = async () => {
    if (!db) return note('waConfirmStatus', 'No database configured.');
    const phone = $('waPhone').value.trim(), body = $('waBody').value.trim(), name = $('waName').value.trim();
    if (!/^[6-9][0-9]{9}$/.test(phone) || name.length < 2 || body.length < 3)
      return note('waConfirmStatus', 'Enter a valid name, phone, and message.');
    const newWindow = window.open('', '_blank');
    try {
      const row = await rpc('prepare_manual_message', { p_category: $('waTemplate').value,
        p_name: name, p_phone: phone, p_body: body });
      state.prepared = { id: row.id, phone, body, name, category: $('waTemplate').value };
      if (newWindow) newWindow.location = 'https://wa.me/91' + phone + '?text=' + encodeURIComponent(body);
      else note('waConfirmStatus', 'Message prepared. Allow popups, then open WhatsApp manually.');
      if (newWindow) note('waConfirmStatus', 'Message prepared. Confirm only after sending in WhatsApp.');
    } catch (error) { newWindow?.close(); fail('waConfirmStatus', error); }
  };
  window.confirmWhatsAppSent = async () => {
    const prepared = state.prepared;
    if (!prepared || prepared.phone !== $('waPhone').value.trim() ||
      prepared.body !== $('waBody').value.trim() || prepared.name !== $('waName').value.trim() ||
      prepared.category !== $('waTemplate').value)
      return note('waConfirmStatus', 'Prepare this exact message first.');
    try {
      await rpc('confirm_manual_message', { p_message_id: prepared.id });
      state.prepared = null; note('waConfirmStatus', 'Manual send marked as confirmed.');
    } catch (error) { fail('waConfirmStatus', error); }
  };
  if (!db) note('loginStatus', 'Set a separate Supabase URL and publishable key in config.js to use this candidate.');
  db?.auth.onAuthStateChange(() => setTimeout(refresh, 0));
  refresh();
})();
